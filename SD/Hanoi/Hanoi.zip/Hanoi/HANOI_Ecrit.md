# Les tours de Hanoï
![kesaco](./images/Hanoi_0.png)
<!-- #### Rappels Pile/File -->
![ex_1-2](./images/Hanoi_ex_1-2.png)
<!-- #### Schémas de principe -->
![ex3](./images/Hanoi_ex3.png)
![ex4](./images/Hanoi_ex4.png)

<div style="page-break-after: always;"></div>

## Programmation en Python

![ex5](./images/Hanoi_ex5.png)

```python
def sommet(pile) :









```
<div style="page-break-after: always;"></div>

![ex6](./images/Hanoi_ex6.png)

```python
def deplacer(origine, cible) :







```
![ex7](./images/Hanoi_ex7.png)

```python



```
![ex8-1](./images/Hanoi_ex8-1.png)

```python

```
![ex8-2](./images/Hanoi_ex8-2.png)

```python



```
![ex9-1](./images/Hanoi_ex9-1.png)
```
nb_etapes(1) = ...
```
![ex9-2](./images/Hanoi_ex9-2.png)
```
nb_etapes(n) = ...
```
![ex9-3](./images/Hanoi_ex9-3.png)
```python
def nb_etapes(n) :







```
